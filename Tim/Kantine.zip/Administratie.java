public class Administratie {
  /**
   * Deze methode berekent van de int array aantal de 
   * gemiddelde waarde
   * @param aantal
   * @return het gemiddelde
   */
  public double berekenGemiddeldAantal(int[] aantal) {
    //omitted
  }

  /**
   * Deze methode berekent van de double array omzet de 
   * gemiddelde waarde
   * @param omzet
   * @return Het gemiddelde
   */
  public double berekenGemiddeldeOmzet(double[] omzet) {
    //omitted
  }
}
