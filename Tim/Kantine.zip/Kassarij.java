c class KassaRij {
  /**
   * Constructor
   */
  public KassaRij() {
    //method body omitted 
  }

  /**
   * Persoon sluit achter in de rij aan
   * @param persoon
   */
  public void sluitAchteraan(Persoon persoon) {
    //method body omitted
  }

  /**
   * Indien er een rij bestaat, de eerste Persoon uit
   * de rij verwijderen en retourneren. 
   * Als er niemand in de rij staat geeft deze null terug.
   * @return Eerste persoon in de rij of null
   */
  public Persoon eerstePersoonInRij() {
    //method body omitted 
  }

  /**
   * Methode kijkt of er personen in de rij staan. 
   * @return Of er wel of geen rij bestaat
   */
  public boolean erIsEenRij() {
    //method body omitted
  }
}
