public class Persoon {
  /**
   * Methode om dienblad te koppelen aan een persoon
   * @param dienblad
   */
  public void pakDienblad(Dienblad) {
    //method body omitted
  } 

  /**
   * Methode om artikel te pakken en te plaatsen op het dienblad
   * @param artikel
   */
  public void pakArtikel(Artikel artikel) {
    //method body omitted
  }

  /**
   * Methode om de totaalprijs van de artikelen 
   * op dienblad dat bij de persoon hoort uit te rekenen
   * @return De totaalprijs
   */
  public double getTotaalPrijs() {
    //method body omitted
  } 

  /**
   * Methode om het aantal artikelen op dienblad dat bij de 
   * persoon hoort te tellen
   * @return Het aantal artikelen
   */
  public int getAantalArtikelen() {
    //method body omitted    
  }
}
